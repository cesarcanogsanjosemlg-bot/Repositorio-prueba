package controlador;
/**
 * @authors César Cano González / Ricardo Ebhotemen Vázquez
 * @fecha 11/02/2026
 * @version 1.0.0
 */

import javax.swing.SwingUtilities;
import vista.Ventana;

public class Main {
	
    public static void main(String[] args) {
        new Controlador().arrancar();
    }
}
